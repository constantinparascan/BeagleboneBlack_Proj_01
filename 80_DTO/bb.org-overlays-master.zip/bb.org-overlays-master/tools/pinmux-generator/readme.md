needs: jq installed
