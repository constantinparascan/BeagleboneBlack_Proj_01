#!/bin/bash

git pull --no-edit git@github.com:beagleboard/bb.org-overlays.git master
git pull --no-edit git@github.com:beagleboard/bb.org-overlays.git master --tags
git pull --no-edit git@github.com:RobertCNelson/bb.org-overlays.git master
git pull --no-edit git@github.com:RobertCNelson/bb.org-overlays.git master --tags

